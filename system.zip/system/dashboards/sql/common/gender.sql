SELECT DISTINCT
    Sex
FROM
    duft.fact_duft_sentinel_event
WHERE
    Sex IS NOT NULL